# Python Module example
# saved in /Users/kevin/Documents/GitHub/Python/Course/Python实战班/In_Class

def add(a, b):
    """ This program adds two numbers
    and return the result"""

    result = a + b
    return result